CREATE DATABASE contact_us;

USE contact_us

CREATE TABLE users( 
	user_id INT PRIMARY KEY AUTO_INCREMENT,
	first_name VARCHAR(25) DEFAULT 'unnamed',
	last_name VARCHAR(25) DEFAULT 'unnamed',
	email VARCHAR(50) DEFAULT 'noemail',
	message VARCHAR(255) DEFAULT 'nomsg'
);

DESC users;

