var express = require('express');
var mysql = require('mysql');
var bodyParser = require('body-parser');

var app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/public'));

var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Password#3',
  database: 'contact_us',
});

app.get('/', function (req, res) {
  res.render('home');
});

app.post('/register', function (req, res) {
  connection.query('INSERT INTO users SET ?', req.body, function (err, result) {
    if (err) throw err;
    console.log(result);
    res.send("thanks for connecting with us. we'll be in touch with you ASAP.");
  });
});

app.listen(8080, function () {
  console.log('Server running on 8080!');
});
